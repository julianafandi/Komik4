const hamburger = document.querySelector(".hamburger-menu");
const menu = document.querySelector(".menu");
const iconSearch = document.querySelector(".icon-search");
const search = document.querySelector(".search-container");
const input = document.querySelector(".search input");
const next = document.querySelector(".next");
const prev = document.querySelector(".prev");
const sliderImage = document.querySelector(".slider-image");
const close = document.querySelector(".close-menu");

let isTransitioning = false;
let autoplayTimer; 
let isAutoplayOn = true; 
let touchStartX = 0;
let touchEndX = 0;
let isMoving = false;
let currentIndex = 0; // Melacak slide aktif saat ini

// ==========================================
// KONTROL PAGINATION (AMBIL DATA DARI HTML)
// ==========================================
// FIX BUG 1: Kunci selektor khusus untuk gambar di dalam SLIDER UTAMA saja
const totalSlides = document.querySelectorAll(".slider-image .image").length; 
const paginationContainer = document.querySelector('.pagination-container'); 

// Generate dot otomatis sesuai jumlah gambar slider utama di HTML
if (paginationContainer && totalSlides > 0) {
    let dotsHtml = "";
    for (let i = 0; i < totalSlides; i++) {
        dotsHtml += `<span class="dot ${i === 0 ? 'active' : ''}" data-index="${i}"></span>`;
    }
    paginationContainer.innerHTML = dotsHtml;
}

// Fungsi Update Visual Dot Aktif
function updatePagination(activeIndex) {
    const dots = document.querySelectorAll('.pagination-container .dot');
    dots.forEach((dot, index) => {
        if (index === activeIndex) {
            dot.classList.add('active');
        } else {
            dot.classList.remove('active');
        }
    });
}

// ==========================================
// LOGIKA NAVIGASI & SWIPE SLIDER
// ==========================================

sliderImage.addEventListener("touchstart", (e) => {
    touchStartX = e.touches[0].clientX;
    isMoving = false; 
    stopAutoplay();
}, { passive: true });

sliderImage.addEventListener("touchmove", (e) => {
    touchEndX = e.touches[0].clientX;
    const currentDistance = Math.abs(touchStartX - touchEndX);
    if (currentDistance > 10) {
        isMoving = true;
    }
}, { passive: true });

sliderImage.addEventListener("touchend", () => {
    if (isMoving) {
        const swipeDistance = touchStartX - touchEndX;
        const threshold = 60; 

        if (swipeDistance > threshold) {
            nextSlide();
        } else if (swipeDistance < -threshold) {
            prevSlide();
        }
    }
    if (isAutoplayOn) {
        startAutoplay();
    }
});

function startAutoplay() {
    clearInterval(autoplayTimer); 
    autoplayTimer = setInterval(nextSlide, 5000); 
}
function stopAutoplay() {
    clearInterval(autoplayTimer);
}

function nextSlide() {
    if (isTransitioning) return;
    isTransitioning = true;

    // FIX BUG 2: Update index dan dot secara instan saat bergeser maju
    if (totalSlides > 0) {
        currentIndex = (currentIndex + 1) % totalSlides;
        updatePagination(currentIndex);
    }

    sliderImage.style.transition = "transform 0.5s ease-in-out";
    sliderImage.style.transform = "translateX(-100%)";
}

function prevSlide() {
    if (isTransitioning) return;
    isTransitioning = true;

    // FIX BUG 2: Update index dan dot secara instan saat bergeser mundur
    if (totalSlides > 0) {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides;
        updatePagination(currentIndex);
    }

    const images = document.querySelectorAll(".slider-image .image");
    sliderImage.prepend(images[images.length - 1]);
    sliderImage.style.transition = "none";
    sliderImage.style.transform = "translateX(-100%)";
    setTimeout(() => {
        sliderImage.style.transition = "transform 0.5s ease-in-out";
        sliderImage.style.transform = "translateX(0%)";
    }, 1);
}

function handleTransitionEnd() {
    isTransitioning = false;
    if (sliderImage.style.transform === "translateX(-100%)") {
        const images = document.querySelectorAll(".slider-image .image");
        sliderImage.appendChild(images[0]);
        sliderImage.style.transition = "none";
        sliderImage.style.transform = "translateX(0%)";
    }
}

// ==========================================
// EVENT LISTENERS & DATA REKOMENDASI
// ==========================================

hamburger.addEventListener("click", () => {
    menu.classList.add("active");
    stopAutoplay();
});
iconSearch.addEventListener("click", () => {
    search.classList.add("active");
    setTimeout(() => { input.focus(); }, 300);
    stopAutoplay();
});
next.addEventListener("click", () => {
    nextSlide();
    startAutoplay(); 
});
prev.addEventListener("click", () => {
    prevSlide();
    startAutoplay();
});

sliderImage.addEventListener("transitionend", handleTransitionEnd);
startAutoplay();

close.addEventListener('click',() => {
    menu.classList.remove("active");
    startAutoplay();
});

// Render slider rekomendasi (terpisah di bagian bawah)
const dataRekomendasi = [
  { id: 1, image: "/image-hero/k.jpg", alt: "Rekomendasi 1" },
  { id: 2, image: "/image-hero/k.jpg", alt: "Rekomendasi 2" },
  { id: 3, image: "/image-hero/k.jpg", alt: "Rekomendasi 3" },
  { id: 4, image: "/image-hero/k.jpg", alt: "Rekomendasi 4" },
  { id: 5, image: "/image-hero/k.jpg", alt: "Rekomendasi 5" },
  { id: 6, image: "/image-hero/k.jpg", alt: "Rekomendasi 6" },
  { id: 7, image: "/image-hero/k.jpg", alt: "Rekomendasi 7" },
];

const sliderRecommended = document.querySelector('.image-recommended');
if (sliderRecommended) {
    sliderRecommended.innerHTML = dataRekomendasi.map(item => `
      <div class="slide-item" data-id="${item.id}">
        <img src="${item.image}" alt="${item.alt}">
      </div>
    `).join('');
}
